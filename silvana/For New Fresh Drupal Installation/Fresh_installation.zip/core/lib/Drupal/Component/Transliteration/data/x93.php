<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = array(
  0x00 => 'lun', 'guo', 'ling', 'bei', 'lu', 'li', 'qiang', 'pou', 'juan', 'min', 'zui', 'peng', 'an', 'pi', 'xian', 'ya',
  0x10 => 'zhui', 'lei', 'ke', 'kong', 'ta', 'kun', 'du', 'nei', 'chui', 'zi', 'zheng', 'ben', 'nie', 'zong', 'chun', 'tan',
  0x20 => 'ding', 'qi', 'qian', 'zhui', 'ji', 'yu', 'jin', 'guan', 'mao', 'chang', 'tian', 'xi', 'lian', 'tao', 'gu', 'cuo',
  0x30 => 'shu', 'zhen', 'lu', 'meng', 'lu', 'hua', 'biao', 'ga', 'lai', 'ken', 'fang', 'wu', 'nai', 'wan', 'zan', 'hu',
  0x40 => 'de', 'xian', 'pian', 'huo', 'liang', 'fa', 'men', 'kai', 'ying', 'di', 'lian', 'guo', 'xian', 'du', 'tu', 'wei',
  0x50 => 'zong', 'fu', 'rou', 'ji', 'e', 'jun', 'chen', 'ti', 'zha', 'hu', 'yang', 'duan', 'xia', 'yu', 'keng', 'xing',
  0x60 => 'huang', 'wei', 'fu', 'zhao', 'cha', 'qie', 'shi', 'hong', 'kui', 'tian', 'mou', 'qiao', 'qiao', 'hou', 'tou', 'cong',
  0x70 => 'huan', 'ye', 'min', 'jian', 'duan', 'jian', 'song', 'kui', 'hu', 'xuan', 'duo', 'jie', 'zhen', 'bian', 'zhong', 'zi',
  0x80 => 'xiu', 'ye', 'mei', 'pai', 'ai', 'jie', 'qian', 'mei', 'suo', 'da', 'bang', 'xia', 'lian', 'suo', 'kai', 'liu',
  0x90 => 'yao', 'ye', 'nou', 'weng', 'rong', 'tang', 'suo', 'qiang', 'li', 'shuo', 'chui', 'bo', 'pan', 'da', 'bi', 'sang',
  0xA0 => 'gang', 'zi', 'wu', 'ying', 'huang', 'tiao', 'liu', 'kai', 'sun', 'sha', 'sou', 'wan', 'hao', 'zhen', 'zhen', 'lang',
  0xB0 => 'yi', 'yuan', 'tang', 'nie', 'xi', 'jia', 'ge', 'ma', 'juan', 'song', 'zu', 'suo', 'xia', 'feng', 'wen', 'na',
  0xC0 => 'lu', 'suo', 'ou', 'zu', 'tuan', 'xiu', 'guan', 'xuan', 'lian', 'shou', 'ao', 'man', 'mo', 'luo', 'bi', 'wei',
  0xD0 => 'liu', 'di', 'san', 'zong', 'yi', 'lu', 'ao', 'keng', 'qiang', 'cui', 'qi', 'chang', 'tang', 'man', 'yong', 'chan',
  0xE0 => 'feng', 'jing', 'biao', 'shu', 'lou', 'xiu', 'cong', 'long', 'zan', 'jian', 'cao', 'li', 'xia', 'xi', 'kang', 'shuang',
  0xF0 => 'beng', 'zhang', 'qian', 'cheng', 'lu', 'hua', 'ji', 'pu', 'hui', 'qiang', 'po', 'lin', 'se', 'xiu', 'san', 'cheng',
);
